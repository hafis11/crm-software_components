import React from 'react'


class Report extends React.Component{
    render(){
        return(
            <div style={{width:'94vw'}}>
            </div>
        )
    }
}
export default Report